import React, { useState, useEffect } from "react";
import { LayoutDashboard, Users, Store, Gift, Ticket, Video, Mail, Newspaper, CheckCircle2, AlertTriangle, CircleDashed, Images, Inbox, UserCog, Link2, ScrollText, ShoppingBag, BadgeCheck, History, Flag, ChevronRight, Info, TrendingUp, Globe, Tag, PenLine, MessageSquareQuote, Palette } from "lucide-react";
import { SideMenuPro } from "@/zy/components/pro/SideMenuPro";
import {
  fetchAdminDiagnostics,
  fetchAdminVueEnsemble,
  fetchModerationAttente, publierProduitVendeur, refuserProduitVendeur,
  fetchCodesPromo, creerCodePromo, basculerCodePromo, supprimerCodePromo,
  fetchAdminCommerceStats, fetchAdminCommerceOrders, changerStatutCommandeAdmin,
  fetchDemandesCollaborateur, fetchCompteDemo, transfererCompteDemo,
  fetchAdminNotifications, testerNotificationsAdmin, fetchAdminATraiter, majDemandeCollaborateur,
  fetchAdminNotificationsSante,
} from "@/zy/lib/kairosApi";
import { toast } from "sonner";
import { AdminEquipe, AdminJournal, AdminModerationFoi } from "@/zy/components/admin/AdminEquipe";
import { Bell } from "lucide-react";
import AdminMarque from "@/zy/components/admin/AdminMarque";
import AdminPrix from "@/zy/components/admin/AdminPrix";
import AdminConnexions from "@/zy/components/admin/AdminConnexions";
import AdminAppLogs from "@/zy/components/admin/AdminAppLogs";
import AdminBranchements from "@/zy/components/admin/AdminBranchements";
import { Utilisateurs, ComptesVendeurs, CatalogueAdmin, Parrainage } from "@/zy/components/admin/AdminGestion";
import { DeploiementBoutique } from "@/zy/components/admin/DeploiementBoutique";
import AdminRetention from "@/zy/components/admin/AdminRetention";
import { useThemePro } from "@/zy/lib/themePro";
import { OFFRES_PAYANTES, NOMS_OFFRES_PAYANTES as NOMS_OFFRES } from "@/zy/lib/droits";
import { AdminVendeursFinances } from "@/zy/components/vendeur/VendeurDokan";

// Menu inspiré de la structure Sentriq (Vue d'ensemble / Utilisateurs / ...).
// Le Parrainage vient de final-main/affiliate.py, les Codes promo de
// ReactZayado/admin_routes.py (2271 lignes) — vraiment portés cette fois,
// pas juste consultés en référence. "Emails IA" et "Articles SEO" restent
// des onglets à venir — annoncés honnêtement comme tels.
const ONGLETS = [
  { key: "vue", label: "Vue d'ensemble", groupe: "Pilotage" },
  { key: "retention", label: "Rétention & Acquisition", groupe: "Pilotage" },
  { key: "journal", label: "Journal des actions", groupe: "Pilotage" },
  { key: "utilisateurs", label: "Utilisateurs", groupe: "Utilisateurs" },
  { key: "equipe", label: "Équipe & accès offerts", groupe: "Utilisateurs" },
  { key: "connexions", label: "Connexions utilisateurs", groupe: "Utilisateurs" },
  { key: "demandes", label: "Demandes collaborateurs", groupe: "Utilisateurs" },
  { key: "notifications", label: "Notifications", groupe: "Utilisateurs" },
  { key: "prix", label: "Prix", groupe: "Ventes" },
  { key: "commerce", label: "Commandes Mollie", groupe: "Ventes" },
  { key: "parrainage", label: "Parrainage", groupe: "Ventes" },
  { key: "codes-promo", label: "Codes promo", groupe: "Ventes" },
  { key: "vendeurs", label: "Modération vendeurs", groupe: "Ventes" },
  { key: "catalogue", label: "Catalogue produits", groupe: "Ventes" },
  { key: "comptes-vendeurs", label: "Comptes vendeurs", groupe: "Ventes" },
  { key: "deploiement", label: "Déploiement boutique (Shopify)", groupe: "Ventes" },
  { key: "moderation-foi", label: "Modération Ma Foi", groupe: "Contenus" },
  { key: "marque", label: "Marque & entreprise", groupe: "Contenus" },
  { key: "branchements", label: "Branchements & clés", groupe: "Technique" },
  { key: "logs", label: "Logs applicatifs", groupe: "Technique" },
  // Compte démo : désactivé en production côté serveur → onglet visible seulement en local.
  ...(typeof window !== "undefined" && /^(localhost|127\.0\.0\.1)$/.test(window.location.hostname)
    ? [{ key: "compte-demo", label: "Compte démo", groupe: "Technique" }] : []),
  { key: "espaces-caches", label: "Site Entreprise & espaces cachés", groupe: "Espaces" },
  { key: "vendeurs-finances", label: "Vendeurs : commission & reversements", groupe: "Espaces" },
];

// Accès rapides réservés à l'admin : pages non listées publiquement (noindex, aucun lien public).
function EspacesCaches() {
  const liens = [
    { href: "/public/tunnel", titre: "Tunnel Zayado (réel) — capture → Kit 27 € → Fast-Track 97 €", desc: "Branché au backend et à Mollie. Les commandes apparaissent dans Commerce (types tunnel_kit / tunnel_fasttrack)." },
    { href: "https://zayado.net/", titre: "Vitrine Zayado (boutique Shopify)", desc: "Accueil, La Maison, De quoi avez-vous besoin, Cockpit, Journal, marketplace. L'ancienne vitrine /public/entreprise redirige ici." },
    { href: "/entreprise?vue=bases", titre: "Mon entreprise — bases & pages", desc: "Classeur Google / Excel et listes Microsoft transformés en pages." },
  ];
  return (
    <div className="space-y-3" data-testid="admin-espaces-caches">
      <p className="text-sm opacity-70">Pages cachées du grand public : accessibles uniquement par ces liens. Elles ne sont pas protégées par mot de passe (pages statiques), mais non référencées.</p>
      {liens.map((l, i) => (
        <a key={l.href} href={l.href} target="_blank" rel="noreferrer" data-testid={`admin-espace-lien-${i}`}
           className="block rounded-xl border border-white/10 p-4 transition-colors hover:border-[#DEC2A3]/60">
          <p className="font-semibold">{l.titre} ↗</p>
          <p className="text-xs opacity-70">{l.desc}</p>
        </a>
      ))}
    </div>
  );
}

// Studio Zayado : vidéos IA, contenus, reprise et tunnels (service séparé, connexion
// par compte Microsoft de l'organisation — aucun jeton Zayado n'y est transmis).
const STUDIO_URL = (import.meta.env.VITE_STUDIO_URL || "https://studio.zayado.net").replace(/\/$/, "");
const ouvrirStudio = () => window.open(STUDIO_URL, "_blank", "noopener");

export default function Admin() {
  const [onglet, setOnglet] = useState("vue");
  const [theme] = useThemePro();

  const ICONS = {
    vue: <LayoutDashboard size={16} />, utilisateurs: <Users size={16} />, vendeurs: <Store size={16} />,
    retention: <TrendingUp size={16} />,
    "pages-pub": <Globe size={16} />, prix: <Tag size={16} />, articles: <PenLine size={16} />, temoignages: <MessageSquareQuote size={16} />,
    parrainage: <Gift size={16} />, "codes-promo": <Ticket size={16} />, commerce: <ShoppingBag size={16} />, catalogue: <Store size={16} />, "comptes-vendeurs": <Users size={16} />, deploiement: <Store size={16} />, "videos-ia": <Video size={16} />,
    "emails-ia": <Mail size={16} />, "articles-seo": <Newspaper size={16} />, notifications: <Bell size={16} />, carrousel: <Images size={16} />,
    demandes: <Inbox size={16} />, "compte-demo": <UserCog size={16} />, newsletters: <Newspaper size={16} />, connexions: <Link2 size={16} />, logs: <ScrollText size={16} />, marque: <Palette size={16} />,
    equipe: <BadgeCheck size={16} />, journal: <History size={16} />, "espaces-caches": <Globe size={16} />, "vendeurs-finances": <Store size={16} />, "tunnels-paiements": <Store size={16} />, "tunnels-admin": <Store size={16} />, "partenaires-financement": <Store size={16} />, "moderation-foi": <Flag size={16} />,
  };
  const menuItems = ONGLETS.map((o) => ({ key: o.key, label: o.label, groupe: o.groupe, icon: ICONS[o.key] }));

  return (
    <div className={`min-h-screen text-offwhite ${theme === "clair" ? "pro-clair pro-cours" : "pro-sombre"}`} data-testid="admin-root">
      <SideMenuPro
        titre="Console Admin"
        sousTitre="Zayado — pilotage plateforme"
        items={menuItems}
        actif={onglet}
        onChange={setOnglet}
        iconesGroupes={{
          Pilotage: <LayoutDashboard size={14} />, Utilisateurs: <Users size={14} />, Ventes: <ShoppingBag size={14} />,
          Contenus: <Newspaper size={14} />, Espaces: <Globe size={14} />, Technique: <UserCog size={14} />,
        }}
        retour={null}
      />
      <div className="min-w-0 px-4 py-5 sm:px-6 lg:ml-[288px] lg:px-10 lg:py-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-serif text-2xl font-bold">{ONGLETS.find((o) => o.key === onglet)?.label || "Admin"}</h1>
        <button onClick={ouvrirStudio} data-testid="admin-ouvrir-studio"
          className="rounded-xl border border-[#DEC2A3]/50 px-3 py-1.5 text-xs font-semibold text-gold hover:bg-white/5"
          title="Vidéos IA, newsletters, articles, témoignages, pages, carrousel, reprise et tunnels">
          Studio : vidéos, contenus, reprise & tunnels ↗
        </button>
      </div>

      <div className="mt-6">
        {onglet === "vue" && <VueEnsemble allerA={setOnglet} />}
        {onglet === "retention" && <AdminRetention />}
        {onglet === "equipe" && <AdminEquipe />}
        {onglet === "journal" && <AdminJournal />}
        {onglet === "moderation-foi" && <AdminModerationFoi />}
        {onglet === "utilisateurs" && <Utilisateurs />}
        {onglet === "vendeurs" && <ModerationVendeurs />}
        {onglet === "prix" && <AdminPrix />}
        {onglet === "commerce" && <CommandesMollie />}
        {onglet === "catalogue" && <CatalogueAdmin />}
        {onglet === "comptes-vendeurs" && <ComptesVendeurs />}
        {onglet === "deploiement" && <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5"><DeploiementBoutique /></div>}
        {onglet === "parrainage" && <Parrainage />}
        {onglet === "codes-promo" && <CodesPromo />}
        {onglet === "demandes" && <DemandesCollaborateur />}
        {onglet === "compte-demo" && <CompteDemo />}
        {onglet === "notifications" && <NotificationsAdmin />}
        {onglet === "marque" && <AdminMarque />}
        {onglet === "connexions" && <AdminConnexions />}
        {onglet === "logs" && <AdminAppLogs />}
        {onglet === "espaces-caches" && <EspacesCaches />}
        {onglet === "vendeurs-finances" && <AdminVendeursFinances />}
        {onglet === "branchements" && <AdminBranchements />}
        {onglet === "articles-seo" && <AVenir label="Articles SEO" description="Génération d'articles SEO par IA — même remarque : référence Sentriq disponible, pas encore de route serveur ici." />}
      </div>
      </div>
    </div>
  );
}

function DemandesCollaborateur() {
  const [donnees, setDonnees] = useState(null);
  const [erreur, setErreur] = useState(null);
  const [reponses, setReponses] = useState({});
  const charger = () => fetchDemandesCollaborateur().then(setDonnees).catch(() => setErreur("Accès refusé ou erreur serveur."));
  useEffect(() => { charger(); }, []);
  const maj = async (d, patch, msg) => {
    try { const r = await majDemandeCollaborateur(d.id, patch); toast.success(msg + (r.email_envoye ? " · e-mail envoyé" : "")); charger(); }
    catch { toast.error("Mise à jour impossible."); }
  };
  if (erreur) return <Carte><p className="text-red-400 text-sm">{erreur}</p></Carte>;
  if (!donnees) return <Carte><p className="text-offwhite/50 text-sm">Chargement…</p></Carte>;
  if (!donnees.demandes.length) return <Carte><p className="text-offwhite/50 text-sm">Aucune demande pour l'instant.</p></Carte>;
  const STATUTS = { nouvelle: "Nouvelle", en_cours: "En cours", traitee: "Traitée" };
  return (
    <div className="space-y-3" data-testid="admin-demandes">
      {donnees.demandes.map((d) => (
        <Carte key={d.id}>
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-offwhite/50">
            <span>{d.created_at ? new Date(d.created_at).toLocaleString("fr-FR") : ""} · {d.email || "compte inconnu"}{d.contact && d.contact !== d.email ? ` · répondre à ${d.contact}` : ""}</span>
            <select value={d.statut} onChange={(e) => maj(d, { statut: e.target.value, prevenir: false }, "Statut mis à jour")}
              className={`rounded-lg border border-white/15 bg-navy-800 px-2 py-1 text-xs ${d.statut === "nouvelle" ? "text-amber-200" : d.statut === "traitee" ? "text-emerald-300" : "text-gold"}`}>
              {Object.entries(STATUTS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </select>
          </div>
          <p className="mt-2 whitespace-pre-wrap text-sm">{d.message}</p>
          {d.reponse && <p className="mt-2 rounded-lg bg-emerald-400/10 px-3 py-2 text-sm text-emerald-200">Ta réponse : {d.reponse}</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <textarea rows={2} value={reponses[d.id] ?? ""} onChange={(e) => setReponses({ ...reponses, [d.id]: e.target.value })}
              placeholder={d.reponse ? "Modifier la réponse…" : "Répondre (visible dans son espace + e-mail)…"}
              className="min-w-[240px] flex-1 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-sm" />
            <button disabled={!(reponses[d.id] || "").trim()} onClick={() => { maj(d, { reponse: reponses[d.id], statut: d.statut === "nouvelle" ? "en_cours" : d.statut }, "Réponse envoyée"); setReponses({ ...reponses, [d.id]: "" }); }}
              className="self-start rounded-xl bg-gold px-4 py-2 text-sm font-semibold text-navy-900 disabled:opacity-40">Répondre</button>
          </div>
        </Carte>
      ))}
    </div>
  );
}

function CompteDemo() {
  const [donnees, setDonnees] = useState(null);
  const [erreur, setErreur] = useState(null);
  const [email, setEmail] = useState("");
  const [choix, setChoix] = useState({});
  const [resultat, setResultat] = useState(null);
  const [envoi, setEnvoi] = useState(false);
  const charger = () => {
    fetchCompteDemo()
      .then((d) => { setDonnees(d); setChoix(Object.fromEntries(d.tables.map((t) => [t.table, true]))); })
      .catch(() => setErreur("Accès refusé ou erreur serveur."));
  };
  useEffect(() => { charger(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const transferer = async () => {
    const tables = Object.keys(choix).filter((k) => choix[k]);
    if (!email.includes("@") || !tables.length) return;
    if (!window.confirm(`Transférer ${tables.length} table(s) du compte démo vers ${email} ? Action définitive.`)) return;
    setEnvoi(true);
    try { setResultat(await transfererCompteDemo(email, tables)); charger(); }
    catch { setResultat({ erreur: "Transfert impossible (e-mail inconnu ou erreur serveur)." }); }
    finally { setEnvoi(false); }
  };
  if (erreur) return <Carte><p className="text-red-400 text-sm">{erreur}</p></Carte>;
  if (!donnees) return <Carte><p className="text-offwhite/50 text-sm">Chargement…</p></Carte>;
  return (
    <div className="space-y-4">
      <Carte>
        <p className="text-sm text-offwhite/70">
          Avant le verrou de connexion, certaines données étaient enregistrées dans le compte démo commun.
          Coche les tables à rattacher, indique l'e-mail du compte réel, puis transfère.
        </p>
      </Carte>
      {!donnees.tables.length && <Carte><p className="text-sm text-offwhite/50">Le compte démo est vide. Rien à récupérer.</p></Carte>}
      {donnees.tables.map((t) => (
        <Carte key={t.table}>
          <label className="flex items-center gap-3 text-sm font-semibold">
            <input type="checkbox" checked={!!choix[t.table]} onChange={(e) => setChoix({ ...choix, [t.table]: e.target.checked })} />
            {t.table} — {t.lignes} ligne(s){t.unique_par_utilisateur ? " · 1 par utilisateur" : ""}
          </label>
          <div className="mt-2 space-y-1 text-xs text-offwhite/50">
            {t.apercu.map((r, i) => <p key={i} className="truncate">{Object.values(r).filter(Boolean).slice(1, 4).join(" · ")}</p>)}
          </div>
        </Carte>
      ))}
      {!!donnees.tables.length && (
        <Carte>
          <div className="flex flex-wrap gap-2">
            <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email du compte réel"
              className="min-w-[240px] flex-1 rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-sm" />
            <button onClick={transferer} disabled={envoi}
              className="rounded-xl bg-gold px-4 py-2 text-sm font-semibold text-navy-900 disabled:opacity-50">
              {envoi ? "Transfert…" : "Transférer"}
            </button>
          </div>
        </Carte>
      )}
      {resultat && (
        <Carte>
          {resultat.erreur ? <p className="text-sm text-red-400">{resultat.erreur}</p> : (
            <div className="text-sm">
              <p className="font-semibold text-gold">Transféré vers {resultat.vers.email}</p>
              {Object.entries(resultat.transferes).map(([k, v]) => <p key={k}>{k} : {v} ligne(s)</p>)}
              {Object.entries(resultat.ignores).map(([k, v]) => <p key={k} className="text-offwhite/50">{k} ignorée : {v}</p>)}
            </div>
          )}
        </Carte>
      )}
    </div>
  );
}

function Carte({ children }) {
  return <div className="min-w-0 rounded-2xl border border-white/10 bg-white/[0.03] p-4 sm:p-5">{children}</div>;
}

const eur = (v) => `${Number(v || 0).toLocaleString("fr-FR", { minimumFractionDigits: 0, maximumFractionDigits: 2 })} €`;

function Kpi({ label, valeur, note, or }) {
  return (
    <Carte>
      <p className="text-offwhite/50 text-xs uppercase tracking-wide">{label}</p>
      <p className={`text-3xl font-bold mt-1 ${or ? "text-gold" : ""}`}>{valeur}</p>
      {note && <p className="mt-1 text-[11px] text-offwhite/45">{note}</p>}
    </Carte>
  );
}

function Branchements() {
  const [d, setD] = useState(null);
  useEffect(() => { fetchAdminDiagnostics().then(setD).catch(() => setD({ erreur: true })); }, []);
  if (!d) return <Carte><p className="text-sm text-offwhite/50">Vérification des branchements…</p></Carte>;
  if (d.erreur || !d.branchements) return <Carte><p className="text-sm text-red-400">Diagnostic indisponible.</p></Carte>;
  const manquants = d.branchements.filter((x) => !x.ok);
  return (
    <Carte>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <p className="font-semibold">Branchements</p>
        <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${manquants.some((x) => x.critique) ? "bg-red-400/15 text-red-300" : manquants.length ? "bg-amber-300/15 text-amber-200" : "bg-emerald-400/15 text-emerald-300"}`} data-testid="admin-branchements-statut">
          {manquants.some((x) => x.critique) ? "À corriger avant la mise en vente" : manquants.length ? `${manquants.length} option(s) non branchée(s)` : "Tout est branché"}
        </span>
      </div>
      <div className="grid gap-2 sm:grid-cols-2" data-testid="admin-branchements">
        {/* Les urgences d'abord : critiques manquants, puis options, puis ce qui est branché. */}
        {[...d.branchements].sort((a, b) => (a.ok - b.ok) || ((b.critique ? 1 : 0) - (a.critique ? 1 : 0))).map((x) => (
          <div key={x.cle} className={`flex min-w-0 gap-2.5 rounded-xl border p-3 ${x.ok ? "border-emerald-300/20 bg-emerald-300/[0.05]" : x.critique ? "border-red-300/30 bg-red-300/[0.07]" : "border-white/10 bg-white/[0.03]"}`}>
            <span className="mt-0.5 shrink-0">{x.ok ? <CheckCircle2 size={16} className="text-emerald-300" /> : x.critique ? <AlertTriangle size={16} className="text-red-300" /> : <CircleDashed size={16} className="text-offwhite/50" />}</span>
            <div className="min-w-0">
              <p className="text-[13.5px] font-semibold">{x.nom}</p>
              {!x.ok && <p className="text-[12px] text-offwhite/60">{x.effet}</p>}
              {!x.ok && <p className="mt-1 text-[11px] text-offwhite/45">Railway (service backend) : {x.variables.map((v) => <code key={v} className="mr-1 break-all rounded bg-white/10 px-1">{v}</code>)}</p>}
            </div>
          </div>
        ))}
      </div>
    </Carte>
  );
}

function ATraiter({ allerA }) {
  const [items, setItems] = useState(null);
  useEffect(() => { fetchAdminATraiter().then((d) => setItems(d.items)).catch(() => setItems([])); }, []);
  const STYLE = { urgent: "border-red-300/30 bg-red-300/[0.07]", a_voir: "border-amber-300/25 bg-amber-300/[0.06]", info: "border-white/10 bg-white/[0.03]" };
  const ICONE = { urgent: <AlertTriangle size={15} className="text-red-300" />, a_voir: <CircleDashed size={15} className="text-amber-200" />, info: <Info size={15} className="text-offwhite/60" /> };
  return (
    <Carte>
      <p className="mb-3 font-semibold">À traiter aujourd'hui</p>
      {!items && <p className="text-sm text-offwhite/50">Chargement…</p>}
      {items?.length === 0 && <p className="flex items-center gap-2 text-sm text-emerald-300" data-testid="admin-a-traiter-vide"><CheckCircle2 size={16} /> Rien d'urgent : tout est à jour.</p>}
      <div className="grid gap-2 sm:grid-cols-2" data-testid="admin-a-traiter">
        {items?.map((x) => (
          <button key={x.cle} onClick={() => allerA(x.onglet)} className={`flex min-w-0 items-center gap-2.5 rounded-xl border p-3 text-left text-sm transition hover:brightness-125 ${STYLE[x.niveau]}`}>
            <span className="shrink-0">{ICONE[x.niveau]}</span><span className="min-w-0 flex-1">{x.texte}</span><ChevronRight size={14} className="shrink-0 text-offwhite/40" />
          </button>
        ))}
      </div>
    </Carte>
  );
}

function VueEnsemble({ allerA }) {
  const [donnees, setDonnees] = useState(null);
  const [erreur, setErreur] = useState(null);
  useEffect(() => {
    fetchAdminVueEnsemble().then(setDonnees).catch(() => setErreur("Accès refusé ou erreur serveur — vérifie que ton compte a bien le rôle admin (déconnecte-toi puis reconnecte-toi après un changement de rôle)."));
  }, []);
  if (erreur) return <Carte><p className="text-red-400 text-sm">{erreur}</p></Carte>;
  if (!donnees) return <Carte><p className="text-offwhite/50 text-sm">Chargement…</p></Carte>;
  const ab = donnees.abonnements || { par_offre: {} };
  return (
    <div className="space-y-4" data-testid="admin-vue">
      <ATraiter allerA={allerA} />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6 sm:gap-4">
        <Kpi label="Revenu mensuel" valeur={eur(ab.mrr_ttc)} note="TTC prélevés — pas de TVA collectée" or />
        <Kpi label="Clients payants" valeur={ab.payants ?? 0} />
        <Kpi label="Essais en cours" valeur={ab.essais_en_cours ?? 0} note="1 € · 1 mois" />
        <Kpi label="Résiliations" valeur={ab.resilies_en_cours ?? 0} note="accès jusqu'à fin de période" />
        <Kpi label="Fondateurs" valeur={ab.fondateurs ?? 0} />
        <Kpi label="Inscrits (7 j)" valeur={donnees.inscrits_7j ?? 0} note={`${donnees.utilisateurs_total} au total`} />
      </div>
      <Carte>
        <p className="mb-3 font-semibold">Abonnés par offre</p>
        <div className="flex flex-wrap gap-2" data-testid="admin-par-offre">
          {OFFRES_PAYANTES.map((k) => (
            <span key={k} className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm">{NOMS_OFFRES[k]} <b className="ml-1 text-gold">{ab.par_offre?.[k] || 0}</b></span>
          ))}
          <span className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-offwhite/60">Vendeurs {donnees.par_role.vendeur} · Admins {donnees.par_role.admin}</span>
        </div>
      </Carte>
      <Carte>
        <p className="mb-1 font-semibold">Accueil — écran de présentation</p>
        <p className="mb-3 text-[12.5px] text-offwhite/55">Combien de nouveaux visiteurs cliquent « Oui, je veux ça » plutôt que « Pas encore ».</p>
        <div className="grid grid-cols-3 gap-3" data-testid="admin-accueil">
          <Kpi label="« Oui, je veux ça »" valeur={donnees.accueil?.oui ?? 0} />
          <Kpi label="« Pas encore »" valeur={donnees.accueil?.pas_encore ?? 0} />
          <Kpi label="Taux d'adhésion" valeur={`${donnees.accueil?.taux_oui ?? 0} %`} note={`${donnees.accueil?.total ?? 0} clics`} or />
        </div>
      </Carte>
      <Branchements />
    </div>
  );
}

function CommandesMollie() {
  const [data, setData] = useState(null); const [stats, setStats] = useState(null);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const load = () => Promise.all([fetchAdminCommerceOrders(status), fetchAdminCommerceStats()]).then(([orders, summary]) => { setData(orders); setStats(summary); }).catch((e) => setError(e.message));
  useEffect(() => { load(); }, [status]); // eslint-disable-line react-hooks/exhaustive-deps
  const update = async (id, next) => { try { await changerStatutCommandeAdmin(id, next); load(); } catch (e) { setError(e.message); } };
  return <div className="space-y-4"><div className="grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4"><Carte><p className="text-xs uppercase tracking-wide text-offwhite/50">Commandes</p><p className="mt-1 text-3xl font-bold">{stats?.total ?? "—"}</p></Carte><Carte><p className="text-xs uppercase tracking-wide text-offwhite/50">Payées</p><p className="mt-1 text-3xl font-bold text-gold">{stats?.paid ?? "—"}</p></Carte><Carte><p className="text-xs uppercase tracking-wide text-offwhite/50">Filtre</p><select value={status} onChange={(e) => setStatus(e.target.value)} className="mt-2 rounded-lg border border-white/15 bg-navy-800 px-2 py-1 text-sm"><option value="">Tous les statuts</option>{["pending", "paid", "failed", "canceled", "expired", "refunded"].map((s) => <option key={s}>{s}</option>)}</select></Carte></div>{error && <Carte><p className="text-sm text-red-400">{error}</p></Carte>}<Carte><div className="overflow-x-auto"><table className="w-full min-w-[760px] text-sm"><thead><tr className="border-b border-white/10 text-left text-offwhite/50"><th className="pb-2">Date</th><th className="pb-2">Client</th><th className="pb-2">Commande</th><th className="pb-2">Montant</th><th className="pb-2">Statut</th><th className="pb-2">Action</th></tr></thead><tbody>{data?.items?.map((o) => <tr key={o.id} className="border-b border-white/5"><td className="py-2.5 text-offwhite/55">{o.created_at ? new Date(o.created_at).toLocaleDateString("fr-FR") : "—"}</td><td className="py-2.5">{o.email}</td><td className="py-2.5"><span className="text-xs text-offwhite/50">{o.kind}</span><br />{o.title}</td><td className="py-2.5">{o.amount} {o.currency}</td><td className="py-2.5"><span className="rounded-full bg-white/10 px-2 py-1 text-xs">{o.status}</span></td><td className="py-2.5"><select value={o.status} onChange={(e) => update(o.id, e.target.value)} className="rounded-lg border border-white/15 bg-navy-800 px-2 py-1 text-xs">{["pending", "paid", "failed", "canceled", "expired", "refunded"].map((s) => <option key={s}>{s}</option>)}</select></td></tr>)}{data && !data.items.length && <tr><td colSpan={6} className="py-6 text-center text-offwhite/50">Aucune commande.</td></tr>}</tbody></table></div></Carte></div>;
}

function ModerationVendeurs() {
  const [items, setItems] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState(null);

  const charger = () => {
    setChargement(true);
    fetchModerationAttente().then((d) => setItems(d.items)).catch(() => setErreur("Accès refusé ou erreur serveur.")).finally(() => setChargement(false));
  };
  useEffect(() => { charger(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const publier = async (pid) => { try { await publierProduitVendeur(pid); charger(); } catch { setErreur("Échec de la publication."); } };
  const refuser = async (pid) => {
    const motif = window.prompt("Motif du refus (visible par le vendeur) :", "");
    if (motif === null) return;
    try { await refuserProduitVendeur(pid, motif); charger(); } catch { setErreur("Échec du refus."); }
  };

  if (erreur) return <Carte><p className="text-red-400 text-sm">{erreur}</p></Carte>;
  if (chargement) return <Carte><p className="text-offwhite/50 text-sm">Chargement…</p></Carte>;
  if (!items.length) return <Carte><p className="text-offwhite/50 text-sm">Aucun produit en attente de modération.</p></Carte>;

  return (
    <div className="space-y-3">
      {items.map((p) => (
        <Carte key={p.id}>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="font-medium">{p.nom || p.titre || "Produit sans nom"}</p>
              <p className="text-offwhite/50 text-xs mt-0.5">{p.id}</p>
            </div>
            <div className="flex gap-2 shrink-0">
              <button onClick={() => publier(p.id)} data-testid={`admin-publier-${p.id}`} className="px-3 py-1.5 rounded-lg bg-gold/15 text-gold text-xs font-semibold hover:bg-gold/25">Publier</button>
              <button onClick={() => refuser(p.id)} data-testid={`admin-refuser-${p.id}`} className="px-3 py-1.5 rounded-lg border border-white/15 text-xs hover:bg-white/10">Refuser</button>
            </div>
          </div>
        </Carte>
      ))}
    </div>
  );
}

function VerifierNotifications({ comptes }) {
  const [email, setEmail] = useState("");
  const [canaux, setCanaux] = useState({ cloche: true, push: true, email: true });
  const [envoi, setEnvoi] = useState(false);
  const [res, setRes] = useState(null);
  const [err, setErr] = useState(null);
  const lancer = async () => {
    setEnvoi(true); setRes(null); setErr(null);
    try {
      setRes(await testerNotificationsAdmin(email.trim(), Object.keys(canaux).filter((k) => canaux[k])));
    } catch (e) {
      setErr(e?.message || "Échec de la vérification.");
    } finally { setEnvoi(false); }
  };
  const NOMS = { cloche: "Cloche (dans l'appli)", push: "Notification mobile / PWA", email: "E-mail" };
  return (
    <Carte>
      <p className="text-offwhite/50 text-xs uppercase tracking-wide mb-1">Vérifier l'envoi pour un utilisateur</p>
      <p className="text-xs text-offwhite/50 mb-3">Saisis l'e-mail d'un compte : il reçoit une notification de test dans la cloche, sur chaque appareil abonné (téléphone, PWA) et par e-mail. Demande-lui de confirmer ce qu'il voit à l'écran.</p>
      <div className="flex flex-wrap gap-2 items-center">
        <input value={email} onChange={(e) => setEmail(e.target.value)} list="comptes-notif" placeholder="email@exemple.com" data-testid="notif-test-email"
          className="flex-1 min-w-[220px] rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm text-offwhite" />
        <datalist id="comptes-notif">{(comptes || []).map((c) => <option key={c.email} value={c.email} />)}</datalist>
        <button onClick={lancer} disabled={envoi || !email.includes("@")} data-testid="notif-test-lancer"
          className="rounded-lg bg-gold px-4 py-2 text-sm font-semibold text-navy disabled:opacity-40">{envoi ? "Envoi…" : "Envoyer le test"}</button>
      </div>
      <div className="flex flex-wrap gap-4 mt-3 text-xs text-offwhite/70">
        {Object.keys(NOMS).map((k) => (
          <label key={k} className="flex items-center gap-1.5"><input type="checkbox" checked={canaux[k]} onChange={(e) => setCanaux({ ...canaux, [k]: e.target.checked })} />{NOMS[k]}</label>
        ))}
      </div>
      {err && <p className="mt-3 text-sm text-red-400" data-testid="notif-test-erreur">{err}</p>}
      {res && (
        <div className="mt-4 space-y-2" data-testid="notif-test-resultat">
          <p className="text-sm text-offwhite/70">Compte testé : <b>{res.compte}</b></p>
          {Object.entries(res.canaux).map(([k, v]) => (
            <div key={k} className="rounded-lg border border-white/10 px-3 py-2">
              <p className="text-sm font-semibold"><span className={v.ok ? "text-emerald-400" : "text-red-400"}>{v.ok ? "✓" : "✗"}</span> {NOMS[k]}</p>
              <p className="text-xs text-offwhite/60 mt-0.5">{v.detail}</p>
              {(v.appareils || []).map((a, i) => (
                <p key={i} className="text-xs text-offwhite/50 mt-0.5">• {a.appareil} — {a.etat === "ok" ? "acceptée" : a.etat === "mort" ? "abonnement expiré (retiré)" : "refusée"}</p>
              ))}
            </div>
          ))}
        </div>
      )}
    </Carte>
  );
}

function SanteNotifications() {
  const [s, setS] = useState(null);
  useEffect(() => {
    fetchAdminNotificationsSante().then(setS).catch(() => setS(false));
  }, []);
  if (s === null) return <Carte><p className="text-offwhite/50 text-sm" data-testid="notif-sante-chargement">Santé des notifications : chargement…</p></Carte>;
  if (s === false) return <Carte><p className="text-red-400 text-sm" data-testid="notif-sante-erreur">Santé des notifications : inaccessible (droits admin requis).</p></Carte>;
  const pushOk = s.push?.ok;
  const LIBELLES_PROBLEME = {
    lib: "pywebpush absent du serveur (pip install -r requirements.txt)",
    cles_absentes: "clés VAPID absentes côté serveur : génère-les (python generer_cles_vapid.py) et ajoute-les aux variables d'environnement",
    cles_incoherentes: "clés VAPID incohérentes : la clé privée ne correspond pas à la clé publique — régénère UNE paire et copie les DEUX",
    sujet_invalide: "VAPID_SUBJECT doit commencer par mailto: ou https://",
  };
  const CANAUX = { push: "Push (téléphone / PWA)", telegram: "Telegram", cloche: "Cloche seule (pas de vibration)" };
  return (
    <div className="space-y-4">
      <Carte>
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <p className="text-offwhite/50 text-xs uppercase tracking-wide">Santé du système de notification</p>
          <span data-testid="notif-sante-push" className={`px-2 py-0.5 rounded-full text-xs font-semibold ${pushOk ? "bg-emerald-400/15 text-emerald-400" : "bg-red-400/15 text-red-400"}`}>
            {pushOk ? "Push prêt" : `Push bloqué — ${LIBELLES_PROBLEME[s.push?.probleme] || s.push?.probleme || "inconnu"}`}
          </span>
        </div>
        {pushOk && s.push?.detail && <p className="text-xs text-offwhite/50 mb-3">{s.push.detail}</p>}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="rounded-lg border border-white/10 px-3 py-2" data-testid="notif-sante-crons">
            <p className="text-offwhite/50 text-xs">Tâches de fond (relances)</p>
            <p className={`text-lg font-bold mt-0.5 ${s.crons_actifs ? "text-emerald-400" : "text-red-400"}`}>{s.crons_actifs ? "Actives" : "Coupées"}</p>
            <p className="text-xs text-offwhite/50 mt-0.5">{s.crons_actifs ? "La boucle tourne toutes les 15 min." : "RUN_CRONS est désactivé : aucune relance ne part."}</p>
          </div>
          <div className="rounded-lg border border-white/10 px-3 py-2" data-testid="notif-sante-appareils">
            <p className="text-offwhite/50 text-xs">Comptes éligibles / appareils abonnés</p>
            <p className="text-lg font-bold mt-0.5">{s.comptes?.eligibles ?? 0} / {s.comptes?.appareils ?? 0}</p>
            <p className="text-xs text-offwhite/50 mt-0.5">éligibles (notifications ON + onboarding fait) / appareils enregistrés</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3 mb-4" data-testid="notif-sante-relances">
          {Object.entries(CANAUX).map(([k, label]) => (
            <div key={k} className="rounded-lg border border-white/10 px-3 py-2">
              <p className="text-offwhite/50 text-xs">7 derniers jours — {label}</p>
              <p className="text-2xl font-bold mt-1">{s.relances_7j?.[k] ?? 0}</p>
            </div>
          ))}
        </div>
        {(s.comptes?.par_compte || []).length > 0 && (
          <p className="text-xs text-offwhite/60 mb-2">Appareils par compte : {s.comptes.par_compte.map((c) => `${c.email} (${c.appareils})`).join(" · ")}</p>
        )}
        {(s.dernieres || []).length > 0 && (
          <div className="overflow-x-auto">
            <p className="text-offwhite/50 text-xs uppercase tracking-wide mb-2">Dernières relances enregistrées</p>
            <table className="w-full min-w-[420px] text-sm">
              <thead><tr className="text-left text-offwhite/50 border-b border-white/10"><th className="pb-1">Type</th><th className="pb-1">Canal</th><th className="pb-1">Jour</th><th className="pb-1">Compte</th></tr></thead>
              <tbody>
                {s.dernieres.map((r, i) => (
                  <tr key={i} className="border-b border-white/5" data-testid={`notif-derniere-${i}`}>
                    <td className="py-1.5">{r.type}</td>
                    <td className="py-1.5">{CANAUX[r.canal] || r.canal}</td>
                    <td className="py-1.5 text-offwhite/60">{r.jour}</td>
                    <td className="py-1.5 text-offwhite/60">{r.email}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Carte>
      <Carte data-testid="notif-regles-calme">
        <p className="text-offwhite/50 text-xs uppercase tracking-wide mb-2">« Pourquoi je ne reçois rien certains jours ? » — les règles de calme</p>
        <ul className="space-y-1.5">
          {s.regles.map((r) => <li key={r} className="text-sm text-offwhite/70 flex gap-2"><span className="text-gold mt-0.5">•</span>{r}</li>)}
        </ul>
        <p className="text-xs text-offwhite/50 mt-3">Ces règles sont voulues : Zayado apaise, il ne harcèle pas. Pour vérifier un compte précis, utilise « Vérifier l'envoi » ci-dessus.</p>
      </Carte>
    </div>
  );
}

function NotificationsAdmin() {
  const [donnees, setDonnees] = useState(null);
  const [erreur, setErreur] = useState(null);
  useEffect(() => {
    fetchAdminNotifications().then(setDonnees).catch(() => setErreur("Accès refusé ou erreur serveur."));
  }, []);
  if (erreur) return <Carte><p className="text-red-400 text-sm">{erreur}</p></Carte>;
  if (!donnees) return <Carte><p className="text-offwhite/50 text-sm">Chargement…</p></Carte>;
  const actifs = donnees.comptes.filter((c) => c.notifications).length;
  return (
    <div className="space-y-4">
      <SanteNotifications />
      <VerifierNotifications comptes={donnees.comptes} />
      <Carte>
        <p className="text-offwhite/50 text-xs uppercase tracking-wide mb-3">Types de notifications envoyées par l'appli</p>
        <div className="grid gap-2 sm:grid-cols-2">
          {donnees.catalogue.map((n) => (
            <div key={n.cle} className="rounded-lg border border-white/10 px-3 py-2">
              <p className="text-sm font-semibold text-offwhite">{n.label}</p>
              <p className="text-xs text-offwhite/50 mt-0.5">{n.desc}</p>
            </div>
          ))}
        </div>
      </Carte>
      <div className="grid grid-cols-2 gap-4">
        <Carte><p className="text-offwhite/50 text-xs uppercase tracking-wide">Comptes avec notifications actives</p><p className="text-3xl font-bold mt-1">{actifs} / {donnees.comptes.length}</p></Carte>
        <Carte><p className="text-offwhite/50 text-xs uppercase tracking-wide">Types catalogués</p><p className="text-3xl font-bold mt-1">{donnees.catalogue.length}</p></Carte>
      </div>
      <Carte>
        <p className="text-offwhite/50 text-xs uppercase tracking-wide mb-2">Qui reçoit quoi</p>
        <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-sm">
          <thead>
            <tr className="text-left text-offwhite/50 border-b border-white/10">
              <th className="pb-2">Compte</th><th className="pb-2">Notifications</th><th className="pb-2">Heure check-in</th><th className="pb-2">Fuseau</th><th className="pb-2">Marché</th>
            </tr>
          </thead>
          <tbody>
            {donnees.comptes.map((c) => (
              <tr key={c.email} className="border-b border-white/5">
                <td className="py-2.5">{c.prenom ? `${c.prenom} · ` : ""}{c.email}</td>
                <td className="py-2.5"><span className={`px-2 py-0.5 rounded-full text-xs ${c.notifications ? "bg-gold/15 text-gold" : "bg-white/10 text-offwhite/50"}`}>{c.notifications ? "Actives" : "Coupées"}</span></td>
                <td className="py-2.5 text-offwhite/70">{c.heure_checkin || "—"}</td>
                <td className="py-2.5 text-offwhite/50">{c.fuseau || "—"}</td>
                <td className="py-2.5 text-offwhite/50">{c.marche}</td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </Carte>
    </div>
  );
}

function CodesPromo() {
  const [items, setItems] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [nouveauCode, setNouveauCode] = useState({ code: "", type: "mois_offert", value: "", max_uses: "100" });

  const charger = () => { setChargement(true); fetchCodesPromo().then((d) => setItems(d.items)).finally(() => setChargement(false)); };
  useEffect(() => { charger(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const creer = async (e) => {
    e.preventDefault();
    try {
      const membre = nouveauCode.type === "thesustain";
      await creerCodePromo({ code: nouveauCode.code, type: nouveauCode.type, value: membre ? 0 : Number(nouveauCode.value),
                             max_uses: Number(nouveauCode.max_uses) || (membre ? 100000 : 100) });
      setNouveauCode({ code: "", type: "mois_offert", value: "", max_uses: "100" });
      charger();
    } catch { /* toast déjà géré par l'appel si besoin */ }
  };
  const basculer = async (p) => { await basculerCodePromo(p.id, !p.active); charger(); };
  const supprimer = async (p) => { if (window.confirm(`Supprimer le code ${p.code} ?`)) { await supprimerCodePromo(p.id); charger(); } };

  return (
    <>
      <Carte>
        <form onSubmit={creer} className="flex gap-2 flex-wrap">
          <input value={nouveauCode.code} onChange={(e) => setNouveauCode((c) => ({ ...c, code: e.target.value }))} placeholder="CODE" className="bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-sm w-32" data-testid="promo-code-input" />
          <select value={nouveauCode.type} onChange={(e) => setNouveauCode((c) => ({ ...c, type: e.target.value, max_uses: e.target.value === "thesustain" ? "100000" : "100" }))} className="bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-sm" aria-label="Type de code" data-testid="promo-type-select">
            <option value="mois_offert">Mois offerts</option>
            <option value="thesustain">Membre TheSustain (remise partenaire)</option>
          </select>
          {nouveauCode.type !== "thesustain" && <input value={nouveauCode.value} onChange={(e) => setNouveauCode((c) => ({ ...c, value: e.target.value }))} placeholder="Mois offerts" type="number" className="bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-sm w-28" data-testid="promo-value-input" />}
          <input value={nouveauCode.max_uses} onChange={(e) => setNouveauCode((c) => ({ ...c, max_uses: e.target.value }))} placeholder="Max usages" type="number" className="bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-sm w-28" data-testid="promo-maxuses-input" />
          <button type="submit" className="px-4 py-2 rounded-xl bg-gold/15 text-gold text-sm font-semibold" data-testid="promo-create-btn">Créer</button>
        </form>
      </Carte>
      {chargement ? <Carte><p className="text-offwhite/50 text-sm">Chargement…</p></Carte> : (
        <Carte>
          <div className="overflow-x-auto"><table className="w-full min-w-[560px] text-sm">
            <thead><tr className="text-left text-offwhite/50 border-b border-white/10"><th className="pb-2">Code</th><th className="pb-2">Valeur</th><th className="pb-2">Usages</th><th className="pb-2">Statut</th><th className="pb-2">Action</th></tr></thead>
            <tbody>
              {items.map((p) => (
                <tr key={p.id} className="border-b border-white/5">
                  <td className="py-2.5 font-mono">{p.code}</td>
                  <td className="py-2.5">{p.type === "thesustain" ? "Membre TheSustain (remise partenaire)" : `${p.value} mois`}</td>
                  <td className="py-2.5">{p.current_uses}/{p.max_uses}</td>
                  <td className="py-2.5"><span className={`px-2 py-0.5 rounded-full text-xs ${p.active ? "bg-gold/15 text-gold" : "bg-white/10"}`}>{p.active ? "actif" : "inactif"}</span></td>
                  <td className="py-2.5 flex gap-2">
                    <button onClick={() => basculer(p)} className="text-xs underline text-offwhite/60 hover:text-offwhite">{p.active ? "désactiver" : "activer"}</button>
                    <button onClick={() => supprimer(p)} className="text-xs underline text-red-400/70 hover:text-red-400">supprimer</button>
                  </td>
                </tr>
              ))}
              {!items.length && <tr><td colSpan={5} className="py-3 text-offwhite/50">Aucun code promo créé.</td></tr>}
            </tbody>
          </table></div>
        </Carte>
      )}
    </>
  );
}

function AVenir({ label, description }) {
  return (
    <Carte>
      <p className="font-medium text-offwhite">{label} — pas encore construit</p>
      <p className="text-offwhite/55 text-sm mt-1.5">{description}</p>
    </Carte>
  );
}
